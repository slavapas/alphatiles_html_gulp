# gulp-pug-sass-boilerplate
Sass &amp; Pug boilerplate using Gulp + BrowserSync

### Usage
- Clone this repository
```
git clone https://github.com/zhyar/gulp-pug-sass-boilerplate
```
- Install the dependencies
```
yarn install
```
- You also need to install the gulp command line utility
```
yarn global add gulp-cli
```
- And you're ready to run the `gulp` command


The default task will start watching the files and run the BrowserSync server.
